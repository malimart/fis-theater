package com.fis.theatre.service;

import org.springframework.stereotype.Service;

@Service
public class TestService {

	public String sayHi() {
		return "hello";
	}
}
